# Event frontend

Event front is a html5 webapp. It's a landing page for an event.

## Installation
/

## Run the app
open the index.html file a browser.

## License
/